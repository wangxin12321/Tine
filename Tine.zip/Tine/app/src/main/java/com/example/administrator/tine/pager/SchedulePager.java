package com.example.administrator.tine.pager;

import android.content.Context;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.example.administrator.tine.R;
import com.example.administrator.tine.base.BasePager;
import com.example.administrator.tine.bean.Databean;

import java.util.ArrayList;

public class SchedulePager extends BasePager {

    private RecyclerView recycler_view;

    private ArrayList<Databean> list;
    private SchedulePagerAdapter schedulePagerAdapter;

    public SchedulePager(Context context) {
        super(context);
    }

    @Override
    public void initData() {
        super.initData();
        View view= View.inflate(context,R.layout.schedule_pager,null);
        recycler_view=view.findViewById(R.id.recycler_view);
        recycler_view.setLayoutManager(new LinearLayoutManager(context));

        list=new ArrayList<Databean>();
        for (int i = 0; i < 24; i++) {
            list.add(new Databean( i+":00", "25/10"));
        }

        schedulePagerAdapter=new SchedulePagerAdapter(context,list);
        recycler_view.setAdapter(schedulePagerAdapter);
        fl_content_pager.addView(view);

    }
}
